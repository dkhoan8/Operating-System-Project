/** PrioritySchedulingAlgorithm.java
 * 
 * A single-queue priority scheduling algorithm.
 *
 * @author: Charles Zhu
 * Spring 2016
 *
 */
package com.jimweller.cpuscheduler;

import java.util.*;

import com.jimweller.cpuscheduler.Process;

public class PrioritySchedulingAlgorithm extends BaseSchedulingAlgorithm implements OptionallyPreemptiveSchedulingAlgorithm {
    
    private PriorityQueue<Process> jobs;
    private boolean yPreemptive;

    PrioritySchedulingAlgorithm(){
        // Fill in this method
        /*------------------------------------------------------------*/
        jobs = new PriorityQueue<Process>
        (800,
            new Comparator<Process>()
            {
                @Override
                public int compare(Process p1, Process p2)
                {
                    if(p1.getPriorityWeight() != p2.getPriorityWeight())
                        return (int)p1.getPriorityWeight() - (int)p2.getPriorityWeight();                    
                    return (int)(p1.getPID() - p2.getPID());
                }
            }
        );
        yPreemptive = false;
        activeJob = null;
        /*------------------------------------------------------------*/
    }

    /** Add the new job to the correct queue.*/
    public void addJob(Process p){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        if(!jobs.contains(p))
            jobs.add(p);
        /*------------------------------------------------------------*/
    }
    
    /** Returns true if the job was present and was removed. */
    public boolean removeJob(Process p){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        return jobs.remove(p);
        /*------------------------------------------------------------*/
    }

    /** Transfer all the jobs in the queue of a SchedulingAlgorithm to another, such as
    when switching to another algorithm in the GUI */
    public void transferJobsTo(SchedulingAlgorithm otherAlg) {
        //throw new UnsupportedOperationException();
        while(jobs.size() != 0)
        {
            otherAlg.addJob(jobs.poll());
        }
    }


    /** Returns the next process that should be run by the CPU, null if none available.*/
    public Process getNextJob(long currentTime){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        //System.out.println("GETNEXTJOB");
        PriorityCase(isPreemptive());
        return activeJob;
        /*------------------------------------------------------------*/
    }

    public String getName(){
        return "Single-Queue Priority";
    }

    /**
     * @return Value of preemptive.
     */
    public boolean isPreemptive(){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        //return yPreemptive;
        return yPreemptive;
        /*------------------------------------------------------------*/
    }
    
    /**
     * @param v Value to assign to preemptive.
     */
    public void setPreemptive(boolean v){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        yPreemptive = v;
        System.out.println("Set preemtive");
        /*------------------------------------------------------------*/
    }
    private void PriorityCase(boolean b)
    {
        if(!b)
        {
            if(isJobFinished())
                activeJob = jobs.poll();
        }
        else
        {
            if(isJobFinished())
                activeJob = jobs.peek();
            else if(jobs.peek().getPriorityWeight() < activeJob.getPriorityWeight())
            {
                activeJob = jobs.peek();
            }
        }
    }
}