/** SJFSchedulingAlgorithm.java
 * 
 * A shortest job first scheduling algorithm.
 *
 * @author: Charles Zhu
 * Spring 2016
 *
 */
package com.jimweller.cpuscheduler;

import java.util.*;

import com.jimweller.cpuscheduler.Process;

public class SJFSchedulingAlgorithm extends BaseSchedulingAlgorithm implements OptionallyPreemptiveSchedulingAlgorithm {
    
    private PriorityQueue<Process> jobs;
    private Vector<Process> preemptiveList;
    private boolean yPreemptive;
    SJFSchedulingAlgorithm(){
        // Fill in this method
        /*------------------------------------------------------------*/
        jobs = new PriorityQueue<Process>
        (800,
            new Comparator<Process>()
            {
                @Override
                public int compare(Process p1, Process p2)
                {
                    if(p1.getInitBurstTime() != p2.getInitBurstTime())
                        return (int)p1.getInitBurstTime() - (int)p2.getInitBurstTime();                    
                    return (int)(p1.getPID() - p2.getPID());
                }
            }
        );
        preemptiveList = new Vector<Process>();
        yPreemptive = false;
        activeJob = null;
        /*------------------------------------------------------------*/
    }

    /** Add the new job to the correct queue.*/
    public void addJob(Process p){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        if(yPreemptive)
        {
            if(!preemptiveList.contains(p))
                preemptiveList.add(p);    
        }
        else if(!jobs.contains(p))
            jobs.add(p);
        /*------------------------------------------------------------*/
    }
    
    /** Returns true if the job was present and was removed. */
    public boolean removeJob(Process p){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        if(yPreemptive)
            return preemptiveList.remove(p);
        return jobs.remove(p);
        /*------------------------------------------------------------*/
    }

    /** Transfer all the jobs in the queue of a SchedulingAlgorithm to another, such as
    when switching to another algorithm in the GUI */
    public void transferJobsTo(SchedulingAlgorithm otherAlg) {
        //throw new UnsupportedOperationException();
        if(!yPreemptive)
        {
            while(jobs.size() != 0)
            {
                otherAlg.addJob(jobs.poll());
            }
        }   
        else
        {
            for (int i = preemptiveList.size()-1; i >= 0; i--) {
                Process job = this.preemptiveList.get(0);
                this.removeJob(job);
                otherAlg.addJob(job);
            }
        }
    }

    /** Returns the next process that should be run by the CPU, null if none available.*/
    public Process getNextJob(long currentTime){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        sort();
        PriorityCase(yPreemptive);
        return activeJob;
        /*------------------------------------------------------------*/
    }

    public String getName(){
        return "Shortest Job First";
    }

    /**
     * @return Value of preemptive.
     */
    public boolean isPreemptive(){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        //return yPreemptive;
        return yPreemptive;
        /*------------------------------------------------------------*/
    }
    
    /**
     * @param v  Value to assign to preemptive.
     */
    public void setPreemptive(boolean  v){
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        yPreemptive = v;
        /*------------------------------------------------------------*/
    }
    private void PriorityCase(boolean b)
    {
        if(!b)
        {
            if(isJobFinished())
                activeJob = jobs.poll();
        }
        else
        {     
            activeJob = preemptiveList.get(0);
        }
    }
    private void sort()
    {
        for(int i = preemptiveList.size() - 1; i >= 1; i--)
        {
            if(preemptiveList.get(i).getBurstTime() <= preemptiveList.get(i-1).getBurstTime())
            {
                boolean switching = true;
                if(preemptiveList.get(i).getBurstTime() == preemptiveList.get(i-1).getBurstTime())
                {
                    if(preemptiveList.get(i).getPID() > preemptiveList.get(i-1).getPID())
                        switching = false;
                }
                if(switching)
                {
                    Process pTemp = preemptiveList.get(i);
                    preemptiveList.set(i,preemptiveList.get(i-1));
                    preemptiveList.set(i-1,pTemp);
                }
            }
        }
        //print();
    }
    private void print()
    {
        for(Process p : preemptiveList)
            System.out.print("pID:" + p.getPID() + "|" + p.getBurstTime() + "---");
        System.out.println();
    }
}