/** RoundRobinSchedulingAlgorithm.java
 * 
 * A scheduling algorithm that randomly picks the next job to go.
 *
 * @author: Kyle Benson
 * Winter 2013
 *
 */
package com.jimweller.cpuscheduler;

import java.util.*;

public class RoundRobinSchedulingAlgorithm extends BaseSchedulingAlgorithm {

    /** the time slice each process gets */
    private int quantum;
    private long time;
    private Vector<Process> list;
    private int currentIndex;

    RoundRobinSchedulingAlgorithm() {
        // Fill in this method
        /*------------------------------------------------------------*/
        list = new Vector<Process>();
        time = (long)quantum;
        currentIndex = -1;
        activeJob = null;
        /*------------------------------------------------------------*/
    }

    /** Add the new job to the correct queue. */
    public void addJob(Process p) {
        // Remove the next lines to start your implementation
        list.add(p);
        sort(list);
        /*------------------------------------------------------------*/
    }

    /** Returns true if the job was present and was removed. */
    public boolean removeJob(Process p) {
        // Remove the next lines to start your implementation
        //throw new UnsupportedOperationException();
        
        // Fill in this method
        /*------------------------------------------------------------*/
        int deletedIndex = 0;
        if(list.contains(p))
        {
            deletedIndex = list.indexOf(p);
            if(deletedIndex > -1 && currentIndex >= deletedIndex)
            {
                try {
                    activeJob = list.get(--currentIndex);
                } catch (Exception e) {
                    activeJob = null;
                }      
            }
            time = 0;
        }
        return list.remove(p);
        /*------------------------------------------------------------*/
    }

    /** Transfer all the jobs in the queue of a SchedulingAlgorithm to another, such as
    when switching to another algorithm in the GUI */
    public void transferJobsTo(SchedulingAlgorithm otherAlg) {
        //throw new UnsupportedOperationException();
        for (int i = list.size()-1; i >= 0; i--) {
            Process job = this.list.get(0);
            this.removeJob(job);
            otherAlg.addJob(job);
        }
    }

    /**
     * Get the value of quantum.
     * 
     * @return Value of quantum.
     */
    public int getQuantum() {
        return quantum;
    }

    /**
     * Set the value of quantum.
     * 
     * @param v
     *            Value to assign to quantum.
     */
    public void setQuantum(int v) {
        this.quantum = v;
    }

    /**
     * Returns the next process that should be run by the CPU, null if none
     * available.
     */
    public Process getNextJob(long currentTime) 
    {
        int nextJobIndex = 0;
        time--;
        if(list.size() == 0)
        {
            currentIndex = -1;
            return null;
        }
        if(time > 0 && currentIndex > -1 && activeJob != null)
            return activeJob;
        else if(currentIndex < 0 || currentIndex >= list.size() - 1)
            nextJobIndex = 0;
        else nextJobIndex = currentIndex + 1;

        activeJob = list.get(nextJobIndex);
        currentIndex = nextJobIndex;
        time = quantum;
        return activeJob;
    }
    public String getName() {
        return "Round Robin";
    }
    private void sort(Vector<Process> list)
    {
        int n = list.size();
        for(int i = 0; i < n; i++)
        {
            for(int j = i; j < n; j++)
            {
                if(list.get(i).getPID() > list.get(j).getPID())
                {
                    Process temp = list.get(j);
                    list.set(j,list.get(i));
                    list.set(i,temp);
                }
            }
        }
        //print();
    }
    private void print(Vector<Process> list)
    {
        if(list.size() == 0)
            return;
        for(Process p : list)
            System.out.print("pID:" + p.getPID() + "-|-");
        System.out.println();
    }
}